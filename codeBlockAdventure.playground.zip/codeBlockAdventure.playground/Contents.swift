/*
 🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉
 👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋👋
 
 ⚠️ ATTENTION!!! ⚠️
 
 Did I get your attention? Good.
 
 Hello! This is Code Block Adventure a playground I made after my frustrations with current
 apps trying to teach coding. Other coding apps are super cool alowing kids to drag and drop to
 make their creations. But it does not really give any second step. I have talked to a bunch of
 middle schoolers that took coding classes and they thought coding was fun but the teachers
 were not prepared to jump them into more complex programming. So they got bored of coding and
 moved on. With Code Block Adventure my idea was to create an in between for block based
 languages and written code. Converting the blocks they click into swift code which later on
 they can start writing swift code instead of using the blocks. If this was a real app I would
 make further levels without the block guy and with more real life coding things. Which they can
 later on transition what they learned in this app to create their own swift apps.
 
 How to use:
 1. Look at the little blue guy you want to get them to move to the brown block (that is the goal) while avoiding the red blocks.
 2. Click the toolbox button to see all of the code blocks you have access to. Clicking one asks you how far you want them to "walk".
 3. Click the play button to test.
 
 Having a problem?
 Because of the lack of time if you mess up you may need to restart. Lucky for you down there is
 a variable called level with a nice little comment above it. There are 5 levels change the
 number to what level you want to skip to.
 
 Also I made this in a 24h hackathon which I talk about in my written part (the only thing I added was more levels and a better look). So it might be a bit messy. Like me.
 */

import UIKit
import PlaygroundSupport
import AudioToolbox

var yOfLine = 385
var yOfScriptButton: CGFloat = -35.0
var view: UIView = UIView()
var scriptView: UIView = UIView()
var mainView: UIView = UIView()

var play: UIButton = UIButton(type: .custom)
var addScript: UIButton = UIButton(type: .roundedRect)
var currentLevelText: UILabel = UILabel()
var map: [[Int]] = [[3, 1, 1, 1],
                    [1, 1, 1, 1],
                    [0, 0, 0, 4]]
var code: [[Int]] = [[],
                     []]

var characterView: UIView = UIView()

var playShown = true

// There are 5 levels if you want to skip levels change this and rerun
var level = 1

var moveCharUp: UIButton = UIButton(type: .custom)
var moveCharDown: UIButton = UIButton(type: .custom)
var moveCharLeft: UIButton = UIButton(type: .custom)
var moveCharRight: UIButton = UIButton(type: .custom)
var scriptButtonLength: Int = 0

class MyViewController : UIViewController {
    @IBOutlet var tiles: Array<UIView> = []
    
    override func loadView() {
        view = UIView()
        view.backgroundColor = UIColor(red: 0.16, green: 0.98, blue: 0.20, alpha: 1.0)
        
        // Toolbox
        scriptView = UIView()
        scriptView.backgroundColor = UIColor(red: 0.20, green: 0.69, blue: 1.00, alpha: 1.0)
        
        let toolboxTitle = UILabel(frame: CGRect(x: 110, y: 0, width: 300, height: 40))
        toolboxTitle.text = "TOOLKIT"
        toolboxTitle.font = UIFont(name: "AmericanTypewriter", size: 30)
        toolboxTitle.textColor = .white
        
        let toolboxTitleLine = UIView(frame: CGRect(x: 0, y: 40, width: 400, height: 4))
        toolboxTitleLine.backgroundColor = .white
        
        let moveText = UILabel(frame: CGRect(x: 20, y: 60, width: 200, height: 40))
        moveText.text = "MOVE"
        moveText.font = UIFont(name: "AmericanTypewriter", size: 30)
        moveText.textColor = .white
        
        let exitText = UILabel(frame: CGRect(x: 75, y: 630, width: 400, height: 40))
        exitText.text = "SWIPE UP TO EXIT"
        exitText.font = UIFont(name: "AmericanTypewriter", size: 25)
        exitText.textColor = .white
        
        scriptView.addSubview(toolboxTitle)
        scriptView.addSubview(toolboxTitleLine)
        scriptView.addSubview(moveText)
        scriptView.addSubview(exitText)
        
        // Main View
        
        mainView = UIView()
        mainView.backgroundColor = UIColor(red: 0.16, green: 0.98, blue: 0.20, alpha: 1.0)
        
        createScriptButton()
        
        let currentLevelBox = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 60))
        currentLevelBox.backgroundColor = UIColor(red: 0.20, green: 0.69, blue: 1.00, alpha: 1.0)
        
        currentLevelText = UILabel(frame: CGRect(x: 130, y: 10, width: 300, height: 40))
        setLevelText(level: level)
        currentLevelText.font = UIFont(name: "AmericanTypewriter", size: 30)
        currentLevelText.textColor = .white
        
        let control = CGRect(x: 305.0, y: 400.0, width: 70.0, height: 62.0)
        let controlBox = UIView(frame: control)
        controlBox.backgroundColor = .white
        
        play.setImage(UIImage(named: "play"), for: .normal)
        play.addTarget(self, action: #selector(playPressed), for: .touchUpInside)
        
        addScript.setTitle("TOOLKIT", for: .normal)
        addScript.titleLabel?.font = UIFont(name: "AmericanTypewriter", size: 14)
        addScript.addTarget(self, action: #selector(scriptAdd), for: .touchUpInside)
        
        let code = CGRect(x: 0.0, y: 400.0, width: 500.0, height: 300.0)
        let codeBox = UIView(frame: code)
        codeBox.backgroundColor = .black
        
        mainView.addSubview(currentLevelBox)
        mainView.addSubview(currentLevelText)
        mainView.addSubview(codeBox)
        mainView.addSubview(controlBox)
        mainView.addSubview(play)
        mainView.addSubview(addScript)
        
        generateNewLevel()
        
        play.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            play.topAnchor.constraint(equalTo: mainView.topAnchor, constant: 400),
            play.trailingAnchor.constraint(equalTo: mainView.trailingAnchor, constant: -10)
        ])
        
        addScript.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            addScript.topAnchor.constraint(equalTo: mainView.topAnchor, constant: 435),
            addScript.trailingAnchor.constraint(equalTo: mainView.trailingAnchor, constant: -2)
            ])
        
        let upSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipes(_:)))
        upSwipe.direction = .up
        scriptView.addGestureRecognizer(upSwipe)
        
        self.view = mainView
    }
    
    @objc func handleSwipes(_ sender:UISwipeGestureRecognizer)
    {
        if (sender.direction == .up)
        {
            self.view = mainView
        }
    }
    
    func switchToScriptView() {
        self.view = scriptView
    }
    
    func switchToMainView() {
        self.view = mainView
    }
    
    func createScriptButton() {
        yOfScriptButton += 35
        
        moveCharUp.setImage(UIImage(named: "moveCharUp"), for: .normal)
        moveCharUp.addTarget(self, action: #selector(moveCharUpClicked), for: .touchUpInside)
        
        moveCharDown.setImage(UIImage(named: "moveCharDown"), for: .normal)
        moveCharDown.addTarget(self, action: #selector(moveCharDownClicked), for: .touchUpInside)
        
        moveCharLeft.setImage(UIImage(named: "moveCharLeft"), for: .normal)
        moveCharLeft.addTarget(self, action: #selector(moveCharLeftClicked), for: .touchUpInside)
        
        moveCharRight.setImage(UIImage(named: "moveCharRight"), for: .normal)
        moveCharRight.addTarget(self, action: #selector(moveCharRightClicked), for: .touchUpInside)
        
        scriptView.addSubview(moveCharUp)
        scriptView.addSubview(moveCharDown)
        scriptView.addSubview(moveCharLeft)
        scriptView.addSubview(moveCharRight)
        scriptView.setNeedsDisplay()
        
        moveCharUp.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            moveCharUp.topAnchor.constraint(equalTo: scriptView.topAnchor, constant: 100),
            moveCharUp.trailingAnchor.constraint(equalTo: scriptView.trailingAnchor, constant: -300)
            ])
        
        moveCharDown.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            moveCharDown.topAnchor.constraint(equalTo: scriptView.topAnchor, constant: 100),
            moveCharDown.trailingAnchor.constraint(equalTo: scriptView.trailingAnchor, constant: -230)
            ])
        
        moveCharLeft.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            moveCharLeft.topAnchor.constraint(equalTo: scriptView.topAnchor, constant: 100),
            moveCharLeft.trailingAnchor.constraint(equalTo: scriptView.trailingAnchor, constant: -160)
            ])
        
        moveCharRight.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            moveCharRight.topAnchor.constraint(equalTo: scriptView.topAnchor, constant: 100),
            moveCharRight.trailingAnchor.constraint(equalTo: scriptView.trailingAnchor, constant: -90)
            ])
    }
    
    func clearCode() {
        let codeCover = UIView(frame: CGRect(x: 0, y: 400, width: 300, height: 200))
        codeCover.backgroundColor = .black
        
        code = [[], []]
        
        yOfLine = 385
        
        mainView.addSubview(codeCover)
        mainView.setNeedsDisplay()
    }
    
    func createNewCodeLine(text: String, color: UIColor) {
        yOfLine += 22
        let label = UILabel()
        label.frame = CGRect(x: 10, y: yOfLine, width: 200, height: 20)
        label.font = UIFont(name: "AmericanTypewriter", size: 20)
        
        label.text = text
        label.textColor = color
        
        mainView.addSubview(label)
        mainView.setNeedsDisplay()
    }
    
    func clearMap() {
        let greenMask = UIView(frame: CGRect(x: 0, y: 61, width: 400, height: 300))
        greenMask.backgroundColor = UIColor(red: 0.16, green: 0.98, blue: 0.20, alpha: 1.0)
        
        mainView.addSubview(greenMask)
        
        mainView.setNeedsDisplay()
    }
    
    func generateMap() {
        var X = -38.0
        var Y = 70.0
        var row = 0.0
        var tileNumber = -1
        
        characterView.removeFromSuperview()
        
        tiles = []
        
        for(index, item) in map.enumerated() {
            for item in item {
                X += 42.0
                
                if (row != Double(index)) {
                    X = 4.0
                    Y += 42.0
                    row = Double(index)
                }
                
                if (item != 0) {
                    let box = CGRect(x: X, y: Y, width: 40.0, height: 40.0)
                    
                    tiles.append(UIView(frame: box))
                    tileNumber += 1
                    if (item == 1) { // Walk
                        tiles[tileNumber].backgroundColor = UIColor(red: 0.97, green: 1.00, blue: 0.76, alpha: 1.0)
                        
                        tiles[tileNumber].layer.borderColor = UIColor.black.cgColor
                        tiles[tileNumber].layer.borderWidth = 1
                    } else if (item == 2) { // Bad Guys
                        tiles[tileNumber].backgroundColor = .red
                    } else if (item == 3) { // Character
                        let character = UIImage(named: "blueguy")
                        characterView = UIImageView(image: character!)
                        characterView.frame = CGRect(x: X, y: Y, width: 40, height: 40)
                        mainView.addSubview(characterView)
                        mainView.setNeedsDisplay()
                        
                        tiles[tileNumber].isHidden = true
                    } else if (item == 4) { // Goal
                        tiles[tileNumber].backgroundColor = .brown
                    }
                    
                    tiles[tileNumber].layer.cornerRadius = 5.0
                    
                    mainView.addSubview(tiles[tileNumber])
                    mainView.setNeedsDisplay()
                }
            }
        }
    }
    
    func move(direction: Int, steps: Int) {
        var win = false
        
        for _ in 1...steps {
            for (index, item) in map.enumerated() {
                var count = 0;
                for item in item {
                    if (item == 3) {
                        if (direction == 0) { // Up
                            if ((map.count < index - 1) && (map[index - 1][count] == 1)) {
                                map[index][count] = 1
                                map[index - 1][count] = 3
                            } else if (map[index - 1][count] == 4) {
                                print("You win!")
                                win = true
                                map[index][count] = 1
                                map[index - 1][count] = 3
                            } else {
                                print("Cannot go up there!")
                            }
                        } else if (direction == 1) { // Down
                            if ((map.count > index + 1) && (map[index + 1][count] == 1)) {
                                map[index][count] = 1
                                map[index + 1][count] = 3
                            } else if (map[index + 1][count] == 4) {
                                print("You win!")
                                map[index][count] = 1
                                map[index + 1][count] = 3
                                win = true
                            } else {
                                print("Cannot go down there!")
                            }
                        } else if (direction == 2) { // Left
                            if ((map[index].count < count - 1) && (map[index][count - 1] == 1)) {
                                map[index][count] = 1
                                map[index][count - 1] = 3
                            } else if (map[index][count - 1] == 4) {
                                print("You win!")
                                map[index][count] = 1
                                map[index][count - 1] = 3
                                win = true
                            } else {
                                print("Cannot go left there!")
                            }
                        } else if (direction == 3) { // Right
                            if ((map[index].count > count + 1) && (map[index][count + 1] == 1)) {
                                map[index][count] = 1
                                map[index][count + 1] = 3
                            } else if (map[index][count + 1] == 4) {
                                print("You win!")
                                map[index][count] = 1
                                map[index][count + 1] = 3
                                win = true
                            } else {
                                print("Cannot go right there!")
                            }
                        }
                        
                        generateMap()
                        
                        if (win) {
                            winLevel()
                        }
                    }
                    count += 1;
                }
            }
        }
    }
    
    func runGame() {
        var count = -1;
        
        for block in code[0] {
            count += 1
            print("Found \(block) and \(code[1][count])")
            move(direction: block, steps: code[1][count])
        }
        
        playPressed()
    }
    
    @objc func playPressed() {
        playShown = !playShown
        if (playShown) {
            generateNewLevel()
            play.setImage(UIImage(named: "play"), for: .normal)
        } else {
            play.setImage(UIImage(named: "stop"), for: .normal)
            generateNewLevel()
            runGame()
        }
    }
    
    @objc func scriptAdd() {
        switchToScriptView()
    }
    
    @objc func moveCharUpClicked() {
        let alert = UIAlertController(title: "How many steps?", message: "", preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.keyboardType = .numberPad
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
            
            self.switchToMainView()
            code[0].append(0)
            code[1].append(Int(textField?.text ?? "0") ?? 0)
            self.createNewCodeLine(text: "moveCharUp(" + (textField?.text ?? "0") + ")", color: .white)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func moveCharDownClicked() {
        let alert = UIAlertController(title: "How many steps?", message: "", preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.keyboardType = .numberPad
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
            
            self.switchToMainView()
            code[0].append(1)
            code[1].append(Int(textField?.text ?? "0") ?? 0)
            self.createNewCodeLine(text: "moveCharDown(" + (textField?.text ?? "0") + ")", color: .white)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func moveCharLeftClicked() {
        let alert = UIAlertController(title: "How many steps?", message: "", preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.keyboardType = .numberPad
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
            
            self.switchToMainView()
            code[0].append(2)
            code[1].append(Int(textField?.text ?? "0") ?? 0)
            self.createNewCodeLine(text: "moveCharLeft(" + (textField?.text ?? "0") + ")", color: .white)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func moveCharRightClicked() {
        let alert = UIAlertController(title: "How many steps?", message: "", preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.keyboardType = .numberPad
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
            
            self.switchToMainView()
            code[0].append(3)
            code[1].append(Int(textField?.text ?? "0") ?? 0)
            self.createNewCodeLine(text: "moveCharRight(" + (textField?.text ?? "0") + ")", color: .white)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func winLevel() {
        createParticles()
        
        if (level != 5) {
            level += 1
            setLevelText(level: level)
        }
    }
    
    func generateNewLevel() {
        if (level == 1) {
            map = [[3, 1, 1, 1],
                   [1, 1, 1, 1],
                   [0, 0, 0, 4]]
        } else if (level == 2) {
            map = [[3, 1, 1, 0],
                   [0, 0, 1, 1],
                   [0, 0, 0, 4]]
        } else if (level == 3) {
            map = [[0, 1, 1, 1],
                   [4, 1, 2, 1],
                   [1, 0, 2, 3],
                   [1, 1, 1, 1]]
        } else if (level == 4) {
            map = [[1, 1, 1, 3],
                   [1, 2, 2, 1],
                   [1, 2, 2, 1],
                   [1, 2, 2, 1],
                   [1, 2, 2, 1],
                   [1, 4, 2, 1]]
        } else if (level == 5) {
            map = [[0, 2, 2, 2],
                   [0, 2, 3, 2],
                   [0, 2, 1, 1],
                   [0, 2, 2, 1],
                   [4, 1, 2, 1],
                   [0, 1, 1, 1]]
        }
        
        clearMap()
        generateMap()
    }
    
    func victorySound() {
        var soundURL: NSURL?
        var soundID: SystemSoundID = 0
        
        let filePath = Bundle.main.path(forResource: "victory_sound", ofType: "aiff")
        soundURL = NSURL(fileURLWithPath: filePath!)
        if let url = soundURL {
            AudioServicesCreateSystemSoundID(url, &soundID)
            AudioServicesPlaySystemSound(soundID)
        }
    }
    
    func setLevelText(level: Int) {
        currentLevelText.text = "LEVEL " + String(level)
    }
    
    func createParticles() {
        victorySound()
        
        let particleEmitter = CAEmitterLayer()
        
        particleEmitter.emitterPosition = CGPoint(x: view.center.x, y: -96)
        particleEmitter.emitterShape = .line
        particleEmitter.emitterSize = CGSize(width: view.frame.size.width, height: 1)
        
        let red = makeEmitterCell(color: UIColor.red)
        let green = makeEmitterCell(color: UIColor.yellow)
        let blue = makeEmitterCell(color: UIColor.blue)
        
        particleEmitter.emitterCells = [red, green, blue]
        
        particleEmitter.zPosition = 10000.0 // Don't hate me.
        mainView.layer.addSublayer(particleEmitter)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            particleEmitter.removeFromSuperlayer()
            self.generateNewLevel()
            self.clearCode()
        }
    }
    
    func makeEmitterCell(color: UIColor) -> CAEmitterCell {
        let cell = CAEmitterCell()
        cell.birthRate = 3
        cell.lifetime = 7.0
        cell.lifetimeRange = 0
        cell.color = color.cgColor
        cell.velocity = 200
        cell.velocityRange = 50
        cell.emissionLongitude = CGFloat.pi
        cell.emissionRange = CGFloat.pi / 4
        cell.spin = 2
        cell.spinRange = 3
        cell.scaleRange = 0.5
        cell.scaleSpeed = -0.05
        
        cell.contents = UIImage(named: "particle_confetti")?.cgImage
        return cell
    }
}

let vc = MyViewController()

PlaygroundPage.current.liveView = vc

